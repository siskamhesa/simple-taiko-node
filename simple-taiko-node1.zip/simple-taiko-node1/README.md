# simple-taiko-node

Get started with the [guide](https://taiko.xyz/docs/guides/run-a-node).
